import rclpy
import serial

from rclpy.node import Node
from std_msgs.msg import String
from sensor_msgs.msg import Imu

imu_pub = None
IMU_FRAME = 116 #This is temporary (probably). 
#https://github.com/bandasaikrishna/orientations_from_IMU_MPU_6050/blob/main/mpu_6050_driver/scripts/imu_node.py

ser = serial.Serial(
                        port = "/dev/ttyACM0",
                        baudrate = 115200,
                        parity = serial.PARITY_NONE,
                        stopbits = serial.STOPBITS_ONE,
                        bytesize = serial.EIGHTBITS,
                        timeout = 60)

class imuPublisher(Node):

    def __init__(self):
        super().__init__("imu_publisher")
        self.publisher_ = self.create_publisher(Imu, 'imu', 10)
        timer_period = 0.125  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        ser.open()

    def timer_callback(self):
        imuMsg = Imu()
        imuMsg.header.frame_id = IMU_FRAME
        ser.write(0x01)
        data = ser.readline()
        data = data.decode()
        capturedInfo = data.split("|")
        
        if (len(capturedInfo) == 7):
            imuMsg.orientation_covariance.x = -1.0
            imuMsg.linear_acceleration.x = float(capturedInfo[0])
            imuMsg.linear_acceleration.y = float(capturedInfo[1])
            imuMsg.linear_acceleration.z = float(capturedInfo[2])
            imuMsg.angular_velocity.x = float(capturedInfo[3])
            imuMsg.angular_velocity.y = float(capturedInfo[4])
            imuMsg.angular_velocity.z = float(capturedInfo[5])
            
        imuMsg.header.stamp = rospy.Time.now()
        imu_publisher.publish(imuMsg)
        
        
def main(args=None):
    rclpy.init(args=args)

    imu_publisher = imuPublisher()

    rclpy.spin(imu_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    imu_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
